/*
 * ExperimentModelPIDAntiwindupDigital_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "ExperimentModelPIDAntiwindupDigital".
 *
 * Model version              : 1.14
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Sun Apr 25 17:31:25 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ExperimentModelPIDAntiwindupDigital.h"
#include "ExperimentModelPIDAntiwindupDigital_private.h"

/* Block parameters (default storage) */
P_ExperimentModelPIDAntiwindupDigital_T ExperimentModelPIDAntiwindupDigital_P =
  {
  /* Variable: sens
   * Referenced by:
   *   '<Root>/1//Rs'
   *   '<Root>/pulse2deg'
   */
  {
    {
      0.5
    },

    {
      2000.0,
      0.18,
      0.0031415926535897933,
      5.5555555555555554,
      318.3098861837907
    },

    {
      {
        10000.0,
        5.0,
        345.0,
        6.0213859193804371
      },
      0.014492753623188406,
      0.83037361613162786,
      69.0,
      1.2042771838760873
    }
  },

  /* Variable: Kd
   * Referenced by: '<S1>/Derivative gain'
   */
  0.14534520548325783,

  /* Variable: Ki
   * Referenced by: '<S1>/Integral gain'
   */
  103.31830777282687,

  /* Variable: Kp
   * Referenced by: '<S1>/Proportional gain'
   */
  8.6651083874998349,

  /* Variable: Kw
   * Referenced by: '<S1>/Antiwindup gain'
   */
  33.333333333333336,

  /* Variable: deg2rad
   * Referenced by: '<S1>/deg2rad'
   */
  0.017453292519943295,

  /* Variable: finalValue
   * Referenced by: '<Root>/Position reference [deg]'
   */
  50.0,

  /* Mask Parameter: AnalogOutput_FinalValue
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: AnalogOutput_InitialValue
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: EncoderInput_InputFilter
   * Referenced by: '<Root>/Encoder Input'
   */
  0.0,

  /* Mask Parameter: AnalogInput_MaxMissedTicks
   * Referenced by: '<Root>/Analog Input'
   */
  10.0,

  /* Mask Parameter: EncoderInput_MaxMissedTicks
   * Referenced by: '<Root>/Encoder Input'
   */
  10.0,

  /* Mask Parameter: AnalogOutput_MaxMissedTicks
   * Referenced by: '<Root>/Analog Output'
   */
  10.0,

  /* Mask Parameter: AnalogInput_YieldWhenWaiting
   * Referenced by: '<Root>/Analog Input'
   */
  0.0,

  /* Mask Parameter: EncoderInput_YieldWhenWaiting
   * Referenced by: '<Root>/Encoder Input'
   */
  0.0,

  /* Mask Parameter: AnalogOutput_YieldWhenWaiting
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: AnalogInput_Channels
   * Referenced by: '<Root>/Analog Input'
   */
  { 0, 1 },

  /* Mask Parameter: EncoderInput_Channels
   * Referenced by: '<Root>/Encoder Input'
   */
  0,

  /* Mask Parameter: AnalogOutput_Channels
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Mask Parameter: AnalogInput_RangeMode
   * Referenced by: '<Root>/Analog Input'
   */
  0,

  /* Mask Parameter: AnalogOutput_RangeMode
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Mask Parameter: AnalogInput_VoltRange
   * Referenced by: '<Root>/Analog Input'
   */
  0,

  /* Mask Parameter: AnalogOutput_VoltRange
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Expression: 1
   * Referenced by: '<Root>/Position reference [deg]'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Position reference [deg]'
   */
  0.0,

  /* Expression: CDer.Numerator{1}
   * Referenced by: '<S1>/Discrete Transfer Fcn'
   */
  { 63.375870995184108, -63.375870995184108 },

  /* Expression: CDer.Denominator{1}
   * Referenced by: '<S1>/Discrete Transfer Fcn'
   */
  { 1.0, -0.93662412900481584 },

  /* Expression: 0
   * Referenced by: '<S1>/Discrete Transfer Fcn'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S1>/Unit Delay'
   */
  0.0,

  /* Expression: CInt.Numerator{1}
   * Referenced by: '<S1>/Discrete Transfer Fcn1'
   */
  { 0.001, 0.0 },

  /* Expression: CInt.Denominator{1}
   * Referenced by: '<S1>/Discrete Transfer Fcn1'
   */
  { 1.0, -1.0 },

  /* Expression: 0
   * Referenced by: '<S1>/Discrete Transfer Fcn1'
   */
  0.0,

  /* Expression: 10
   * Referenced by: '<S1>/Saturation'
   */
  10.0,

  /* Expression: -10
   * Referenced by: '<S1>/Saturation'
   */
  -10.0
};
