for k = 1:1
    for j = 2:2
        Ts = tmpTs(j);
        if k == 1
            method = 'BE';
            [CInt,CDer] = discretizedPID(method,Ts,Tl);
        elseif k == 2
            method = 'FE';
            [CInt,CDer] = discretizedPID(method,Ts,Tl);
        elseif k == 3
            method = 'tustin';
            [CInt,CDer] = discretizedPID(method,Ts,Tl);
        end
        open_system('ExperimentModelPIDFeedFowardDigital');
        set_param('ExperimentModelPIDFeedFowardDigital','SimulationMode','external')
        set_param('ExperimentModelPIDFeedFowardDigital','SimulationCommand','connect')
        set_param('ExperimentModelPIDFeedFowardDigital','SimulationCommand','start');
        while strcmp('stopped',get_param('ExperimentModelPIDFeedFowardDigital','SimulationStatus'))
            pause(2);
        end
        
        close_system('ExperimentModelPIDFeedFowardDigital');
        out.ScopeThl = ScopeThl;
        out.ScopeDataIa = ScopeDataIa;
        out.ScopeThl = ScopeThl;
        out.ScopeDataIa = ScopeDataIa;
        out.ts5 = ts5;
        out.Mp = Mp;
        out.Ki = Ki;
        out.Kp = Kp;
        out.Kd = Kd;
        out.Tw = Tw;
        out.Tl = Tl;
        out.Ts = Ts;
        out.alpha = alpha;
        saver(strcat('ExperimentModelPIDFeedFowardDigital',method),out);
        clear out;
    end
end