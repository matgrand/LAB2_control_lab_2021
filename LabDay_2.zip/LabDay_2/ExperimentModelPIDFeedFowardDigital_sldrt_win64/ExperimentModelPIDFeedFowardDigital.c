/*
 * ExperimentModelPIDFeedFowardDigital.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "ExperimentModelPIDFeedFowardDigital".
 *
 * Model version              : 1.13
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Sun Apr 25 17:33:32 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ExperimentModelPIDFeedFowardDigital.h"
#include "ExperimentModelPIDFeedFowardDigital_private.h"
#include "ExperimentModelPIDFeedFowardDigital_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  2.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.001, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6221", 4294967295U, 5, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_ExperimentModelPIDFeedFowardDigital_T ExperimentModelPIDFeedFowardDigital_B;

/* Block states (default storage) */
DW_ExperimentModelPIDFeedFowardDigital_T ExperimentModelPIDFeedFowardDigital_DW;

/* Real-time model */
static RT_MODEL_ExperimentModelPIDFeedFowardDigital_T
  ExperimentModelPIDFeedFowardDigital_M_;
RT_MODEL_ExperimentModelPIDFeedFowardDigital_T *const
  ExperimentModelPIDFeedFowardDigital_M =
  &ExperimentModelPIDFeedFowardDigital_M_;
static void rate_scheduler(void);

/*
 *   This function updates active task flag for each subrate.
 * The function is called at model base rate, hence the
 * generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (ExperimentModelPIDFeedFowardDigital_M->Timing.TaskCounters.TID[1])++;
  if ((ExperimentModelPIDFeedFowardDigital_M->Timing.TaskCounters.TID[1]) > 499)
  {                                    /* Sample time: [0.5s, 0.0s] */
    ExperimentModelPIDFeedFowardDigital_M->Timing.TaskCounters.TID[1] = 0;
  }

  ExperimentModelPIDFeedFowardDigital_M->Timing.sampleHits[1] =
    (ExperimentModelPIDFeedFowardDigital_M->Timing.TaskCounters.TID[1] == 0);
}

/* Model output function */
void ExperimentModelPIDFeedFowardDigital_output(void)
{
  /* local block i/o variables */
  real_T rtb_AnalogInput[2];
  real_T rtb_Sum;
  real_T rtb_Sum_k;
  real_T rtb_Gain1;
  real_T rtb_Gain4;
  real_T rtb_Saturation;
  real_T y;
  uint8_T rtb_Output;

  /* S-Function (sldrtai): '<Root>/Analog Input' */
  /* S-Function Block: <Root>/Analog Input */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE)
      ExperimentModelPIDFeedFowardDigital_P.AnalogInput_RangeMode;
    parm.rangeidx = ExperimentModelPIDFeedFowardDigital_P.AnalogInput_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 2,
                   ExperimentModelPIDFeedFowardDigital_P.AnalogInput_Channels,
                   &rtb_AnalogInput[0], &parm);
  }

  /* S-Function (sldrtei): '<Root>/Encoder Input' */
  /* S-Function Block: <Root>/Encoder Input */
  {
    ENCODERINPARM parm;
    parm.quad = (QUADMODE) 2;
    parm.index = (INDEXPULSE) 0;
    parm.infilter =
      ExperimentModelPIDFeedFowardDigital_P.EncoderInput_InputFilter;
    RTBIO_DriverIO(0, ENCODERINPUT, IOREAD, 1,
                   &ExperimentModelPIDFeedFowardDigital_P.EncoderInput_Channels,
                   &rtb_Sum_k, &parm);
  }

  /* Gain: '<Root>/1//Rs' incorporates:
   *  Sum: '<Root>/Add'
   */
  ExperimentModelPIDFeedFowardDigital_B.armaturecurrent = 1.0 /
    ExperimentModelPIDFeedFowardDigital_P.sens.curr.Rs * (rtb_AnalogInput[0] -
    rtb_AnalogInput[1]);
  if (ExperimentModelPIDFeedFowardDigital_M->Timing.TaskCounters.TID[1] == 0) {
    /* UnitDelay: '<S4>/Output' */
    rtb_Output = ExperimentModelPIDFeedFowardDigital_DW.Output_DSTATE;

    /* MultiPortSwitch: '<S2>/Output' incorporates:
     *  Constant: '<S2>/Vector'
     *  UnitDelay: '<S4>/Output'
     */
    ExperimentModelPIDFeedFowardDigital_B.Output =
      ExperimentModelPIDFeedFowardDigital_P.a_refrpms_OutValues[ExperimentModelPIDFeedFowardDigital_DW.Output_DSTATE];
  }

  /* DiscreteIntegrator: '<Root>/Discrete-Time Integrator' incorporates:
   *  ZeroOrderHold: '<Root>/Zero-Order Hold1'
   */
  ExperimentModelPIDFeedFowardDigital_B.DiscreteTimeIntegrator =
    ExperimentModelPIDFeedFowardDigital_P.DiscreteTimeIntegrator_gainval *
    ExperimentModelPIDFeedFowardDigital_B.Output +
    ExperimentModelPIDFeedFowardDigital_DW.DiscreteTimeIntegrator_DSTATE;

  /* Gain: '<Root>/rpm2rads' */
  rtb_Saturation = ExperimentModelPIDFeedFowardDigital_P.rpm2rads *
    ExperimentModelPIDFeedFowardDigital_B.DiscreteTimeIntegrator;

  /* Gain: '<S1>/Gain1' */
  rtb_Gain1 = 196.0 * ExperimentModelPIDFeedFowardDigital_P.Beq * rtb_Saturation;

  /* Signum: '<S1>/Sign' */
  if (rtb_Saturation < 0.0) {
    y = -1.0;
  } else if (rtb_Saturation > 0.0) {
    y = 1.0;
  } else if (rtb_Saturation == 0.0) {
    y = 0.0;
  } else {
    y = (rtNaN);
  }

  /* End of Signum: '<S1>/Sign' */

  /* Gain: '<S1>/Gain4' */
  rtb_Gain4 = ExperimentModelPIDFeedFowardDigital_P.gbox.N1 *
    ExperimentModelPIDFeedFowardDigital_P.mot.ke /
    ExperimentModelPIDFeedFowardDigital_P.drv.dcgain * rtb_Saturation;

  /* DiscreteIntegrator: '<Root>/Discrete-Time Integrator1' incorporates:
   *  Gain: '<Root>/rpm2degs'
   */
  ExperimentModelPIDFeedFowardDigital_B.DiscreteTimeIntegrator1 =
    ExperimentModelPIDFeedFowardDigital_P.rpm2degs *
    ExperimentModelPIDFeedFowardDigital_B.DiscreteTimeIntegrator *
    ExperimentModelPIDFeedFowardDigital_P.DiscreteTimeIntegrator1_gainval +
    ExperimentModelPIDFeedFowardDigital_DW.DiscreteTimeIntegrator1_DSTATE;

  /* Gain: '<Root>/pulse2deg' */
  ExperimentModelPIDFeedFowardDigital_B.thl_meas =
    ExperimentModelPIDFeedFowardDigital_P.sens.enc.pulse2deg * rtb_Sum_k;

  /* Gain: '<S3>/deg2rad' incorporates:
   *  Sum: '<Root>/Sum1'
   */
  rtb_Saturation =
    (ExperimentModelPIDFeedFowardDigital_B.DiscreteTimeIntegrator1 -
     ExperimentModelPIDFeedFowardDigital_B.thl_meas) *
    ExperimentModelPIDFeedFowardDigital_P.deg2rad;

  /* DiscreteTransferFcn: '<S3>/Discrete Transfer Fcn' incorporates:
   *  Gain: '<S3>/Derivative gain'
   */
  ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn_tmp =
    (ExperimentModelPIDFeedFowardDigital_P.Kd * rtb_Saturation -
     ExperimentModelPIDFeedFowardDigital_P.DiscreteTransferFcn_DenCoef[1] *
     ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn_states) /
    ExperimentModelPIDFeedFowardDigital_P.DiscreteTransferFcn_DenCoef[0];

  /* Sum: '<S3>/Sum' incorporates:
   *  DiscreteTransferFcn: '<S3>/Discrete Transfer Fcn'
   */
  rtb_Sum_k = ExperimentModelPIDFeedFowardDigital_P.DiscreteTransferFcn_NumCoef
    [0] * ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn_tmp +
    ExperimentModelPIDFeedFowardDigital_P.DiscreteTransferFcn_NumCoef[1] *
    ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn_states;

  /* DiscreteTransferFcn: '<S3>/Discrete Transfer Fcn1' incorporates:
   *  Gain: '<S3>/Antiwindup gain'
   *  Gain: '<S3>/Integral gain'
   *  Sum: '<S3>/Sum2'
   *  UnitDelay: '<S3>/Unit Delay'
   */
  ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn1_tmp =
    ((ExperimentModelPIDFeedFowardDigital_P.Ki * rtb_Saturation -
      ExperimentModelPIDFeedFowardDigital_P.Kw *
      ExperimentModelPIDFeedFowardDigital_DW.UnitDelay_DSTATE) -
     ExperimentModelPIDFeedFowardDigital_P.DiscreteTransferFcn1_DenCoef[1] *
     ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn1_states) /
    ExperimentModelPIDFeedFowardDigital_P.DiscreteTransferFcn1_DenCoef[0];

  /* Sum: '<S3>/Sum' incorporates:
   *  DiscreteTransferFcn: '<S3>/Discrete Transfer Fcn1'
   *  Gain: '<S3>/Proportional gain'
   */
  rtb_Sum_k = (ExperimentModelPIDFeedFowardDigital_P.Kp * rtb_Saturation +
               rtb_Sum_k) +
    (ExperimentModelPIDFeedFowardDigital_P.DiscreteTransferFcn1_NumCoef[0] *
     ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn1_tmp +
     ExperimentModelPIDFeedFowardDigital_P.DiscreteTransferFcn1_NumCoef[1] *
     ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn1_states);

  /* Saturate: '<S3>/Saturation' */
  if (rtb_Sum_k > ExperimentModelPIDFeedFowardDigital_P.Saturation_UpperSat) {
    rtb_Saturation = ExperimentModelPIDFeedFowardDigital_P.Saturation_UpperSat;
  } else if (rtb_Sum_k <
             ExperimentModelPIDFeedFowardDigital_P.Saturation_LowerSat) {
    rtb_Saturation = ExperimentModelPIDFeedFowardDigital_P.Saturation_LowerSat;
  } else {
    rtb_Saturation = rtb_Sum_k;
  }

  /* End of Saturate: '<S3>/Saturation' */

  /* Sum: '<S1>/Sum' incorporates:
   *  Gain: '<Root>/rpms2radss'
   *  Gain: '<S1>/Gain'
   *  Gain: '<S1>/Gain2'
   *  Gain: '<S1>/Gain3'
   *  Sum: '<S1>/Sum1'
   *  Sum: '<S1>/Sum2'
   *  Sum: '<S1>/Sum3'
   *  ZeroOrderHold: '<Root>/Zero-Order Hold1'
   */
  rtb_Sum = ExperimentModelPIDFeedFowardDigital_P.gbox.N1 *
    ExperimentModelPIDFeedFowardDigital_P.Req *
    ExperimentModelPIDFeedFowardDigital_P.Jeq /
    ExperimentModelPIDFeedFowardDigital_P.drv.dcgain /
    ExperimentModelPIDFeedFowardDigital_P.mot.Kt *
    (ExperimentModelPIDFeedFowardDigital_P.rpm2rads *
     ExperimentModelPIDFeedFowardDigital_B.Output) +
    (ExperimentModelPIDFeedFowardDigital_P.Req /
     ExperimentModelPIDFeedFowardDigital_P.drv.dcgain /
     ExperimentModelPIDFeedFowardDigital_P.mot.Kt /
     ExperimentModelPIDFeedFowardDigital_P.gbox.N1 *
     (ExperimentModelPIDFeedFowardDigital_P.mld.tausf * y + rtb_Gain1) +
     (rtb_Gain4 + rtb_Saturation));

  /* S-Function (sldrtao): '<Root>/Analog Output' */
  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE)
        ExperimentModelPIDFeedFowardDigital_P.AnalogOutput_RangeMode;
      parm.rangeidx =
        ExperimentModelPIDFeedFowardDigital_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &ExperimentModelPIDFeedFowardDigital_P.AnalogOutput_Channels,
                     ((real_T*) (&rtb_Sum)), &parm);
    }
  }

  /* Sum: '<S3>/Sum1' */
  ExperimentModelPIDFeedFowardDigital_B.Sum1 = rtb_Sum_k - rtb_Saturation;
  if (ExperimentModelPIDFeedFowardDigital_M->Timing.TaskCounters.TID[1] == 0) {
    /* Sum: '<S5>/FixPt Sum1' incorporates:
     *  Constant: '<S5>/FixPt Constant'
     */
    rtb_Output = (uint8_T)((uint32_T)rtb_Output +
      ExperimentModelPIDFeedFowardDigital_P.FixPtConstant_Value);

    /* Switch: '<S6>/FixPt Switch' */
    if (rtb_Output >
        ExperimentModelPIDFeedFowardDigital_P.LimitedCounter_uplimit) {
      /* Switch: '<S6>/FixPt Switch' incorporates:
       *  Constant: '<S6>/Constant'
       */
      ExperimentModelPIDFeedFowardDigital_B.FixPtSwitch =
        ExperimentModelPIDFeedFowardDigital_P.Constant_Value;
    } else {
      /* Switch: '<S6>/FixPt Switch' */
      ExperimentModelPIDFeedFowardDigital_B.FixPtSwitch = rtb_Output;
    }

    /* End of Switch: '<S6>/FixPt Switch' */
  }
}

/* Model update function */
void ExperimentModelPIDFeedFowardDigital_update(void)
{
  if (ExperimentModelPIDFeedFowardDigital_M->Timing.TaskCounters.TID[1] == 0) {
    /* Update for UnitDelay: '<S4>/Output' */
    ExperimentModelPIDFeedFowardDigital_DW.Output_DSTATE =
      ExperimentModelPIDFeedFowardDigital_B.FixPtSwitch;
  }

  /* Update for DiscreteIntegrator: '<Root>/Discrete-Time Integrator' */
  ExperimentModelPIDFeedFowardDigital_DW.DiscreteTimeIntegrator_DSTATE =
    ExperimentModelPIDFeedFowardDigital_B.DiscreteTimeIntegrator;

  /* Update for DiscreteIntegrator: '<Root>/Discrete-Time Integrator1' */
  ExperimentModelPIDFeedFowardDigital_DW.DiscreteTimeIntegrator1_DSTATE =
    ExperimentModelPIDFeedFowardDigital_B.DiscreteTimeIntegrator1;

  /* Update for DiscreteTransferFcn: '<S3>/Discrete Transfer Fcn' */
  ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn_states =
    ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn_tmp;

  /* Update for UnitDelay: '<S3>/Unit Delay' */
  ExperimentModelPIDFeedFowardDigital_DW.UnitDelay_DSTATE =
    ExperimentModelPIDFeedFowardDigital_B.Sum1;

  /* Update for DiscreteTransferFcn: '<S3>/Discrete Transfer Fcn1' */
  ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn1_states =
    ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn1_tmp;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++ExperimentModelPIDFeedFowardDigital_M->Timing.clockTick0)) {
    ++ExperimentModelPIDFeedFowardDigital_M->Timing.clockTickH0;
  }

  ExperimentModelPIDFeedFowardDigital_M->Timing.t[0] =
    ExperimentModelPIDFeedFowardDigital_M->Timing.clockTick0 *
    ExperimentModelPIDFeedFowardDigital_M->Timing.stepSize0 +
    ExperimentModelPIDFeedFowardDigital_M->Timing.clockTickH0 *
    ExperimentModelPIDFeedFowardDigital_M->Timing.stepSize0 * 4294967296.0;
  if (ExperimentModelPIDFeedFowardDigital_M->Timing.TaskCounters.TID[1] == 0) {
    /* Update absolute timer for sample time: [0.5s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++ExperimentModelPIDFeedFowardDigital_M->Timing.clockTick1)) {
      ++ExperimentModelPIDFeedFowardDigital_M->Timing.clockTickH1;
    }

    ExperimentModelPIDFeedFowardDigital_M->Timing.t[1] =
      ExperimentModelPIDFeedFowardDigital_M->Timing.clockTick1 *
      ExperimentModelPIDFeedFowardDigital_M->Timing.stepSize1 +
      ExperimentModelPIDFeedFowardDigital_M->Timing.clockTickH1 *
      ExperimentModelPIDFeedFowardDigital_M->Timing.stepSize1 * 4294967296.0;
  }

  rate_scheduler();
}

/* Model initialize function */
void ExperimentModelPIDFeedFowardDigital_initialize(void)
{
  /* Start for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE)
        ExperimentModelPIDFeedFowardDigital_P.AnalogOutput_RangeMode;
      parm.rangeidx =
        ExperimentModelPIDFeedFowardDigital_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &ExperimentModelPIDFeedFowardDigital_P.AnalogOutput_Channels,
                     &ExperimentModelPIDFeedFowardDigital_P.AnalogOutput_InitialValue,
                     &parm);
    }
  }

  /* InitializeConditions for S-Function (sldrtei): '<Root>/Encoder Input' */

  /* S-Function Block: <Root>/Encoder Input */
  {
    ENCODERINPARM parm;
    parm.quad = (QUADMODE) 2;
    parm.index = (INDEXPULSE) 0;
    parm.infilter =
      ExperimentModelPIDFeedFowardDigital_P.EncoderInput_InputFilter;
    RTBIO_DriverIO(0, ENCODERINPUT, IORESET, 1,
                   &ExperimentModelPIDFeedFowardDigital_P.EncoderInput_Channels,
                   NULL, &parm);
  }

  /* InitializeConditions for UnitDelay: '<S4>/Output' */
  ExperimentModelPIDFeedFowardDigital_DW.Output_DSTATE =
    ExperimentModelPIDFeedFowardDigital_P.Output_InitialCondition;

  /* InitializeConditions for DiscreteIntegrator: '<Root>/Discrete-Time Integrator' */
  ExperimentModelPIDFeedFowardDigital_DW.DiscreteTimeIntegrator_DSTATE =
    ExperimentModelPIDFeedFowardDigital_P.DiscreteTimeIntegrator_IC;

  /* InitializeConditions for DiscreteIntegrator: '<Root>/Discrete-Time Integrator1' */
  ExperimentModelPIDFeedFowardDigital_DW.DiscreteTimeIntegrator1_DSTATE =
    ExperimentModelPIDFeedFowardDigital_P.DiscreteTimeIntegrator1_IC;

  /* InitializeConditions for DiscreteTransferFcn: '<S3>/Discrete Transfer Fcn' */
  ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn_states =
    ExperimentModelPIDFeedFowardDigital_P.DiscreteTransferFcn_InitialStates;

  /* InitializeConditions for UnitDelay: '<S3>/Unit Delay' */
  ExperimentModelPIDFeedFowardDigital_DW.UnitDelay_DSTATE =
    ExperimentModelPIDFeedFowardDigital_P.UnitDelay_InitialCondition;

  /* InitializeConditions for DiscreteTransferFcn: '<S3>/Discrete Transfer Fcn1' */
  ExperimentModelPIDFeedFowardDigital_DW.DiscreteTransferFcn1_states =
    ExperimentModelPIDFeedFowardDigital_P.DiscreteTransferFcn1_InitialStates;
}

/* Model terminate function */
void ExperimentModelPIDFeedFowardDigital_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE)
        ExperimentModelPIDFeedFowardDigital_P.AnalogOutput_RangeMode;
      parm.rangeidx =
        ExperimentModelPIDFeedFowardDigital_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &ExperimentModelPIDFeedFowardDigital_P.AnalogOutput_Channels,
                     &ExperimentModelPIDFeedFowardDigital_P.AnalogOutput_FinalValue,
                     &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  ExperimentModelPIDFeedFowardDigital_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  ExperimentModelPIDFeedFowardDigital_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  ExperimentModelPIDFeedFowardDigital_initialize();
}

void MdlTerminate(void)
{
  ExperimentModelPIDFeedFowardDigital_terminate();
}

/* Registration function */
RT_MODEL_ExperimentModelPIDFeedFowardDigital_T
  *ExperimentModelPIDFeedFowardDigital(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  ExperimentModelPIDFeedFowardDigital_P.EncoderInput_InputFilter = rtInf;

  /* initialize real-time model */
  (void) memset((void *)ExperimentModelPIDFeedFowardDigital_M, 0,
                sizeof(RT_MODEL_ExperimentModelPIDFeedFowardDigital_T));

  /* Initialize timing info */
  {
    int_T *mdlTsMap =
      ExperimentModelPIDFeedFowardDigital_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    ExperimentModelPIDFeedFowardDigital_M->Timing.sampleTimeTaskIDPtr =
      (&mdlTsMap[0]);
    ExperimentModelPIDFeedFowardDigital_M->Timing.sampleTimes =
      (&ExperimentModelPIDFeedFowardDigital_M->Timing.sampleTimesArray[0]);
    ExperimentModelPIDFeedFowardDigital_M->Timing.offsetTimes =
      (&ExperimentModelPIDFeedFowardDigital_M->Timing.offsetTimesArray[0]);

    /* task periods */
    ExperimentModelPIDFeedFowardDigital_M->Timing.sampleTimes[0] = (0.001);
    ExperimentModelPIDFeedFowardDigital_M->Timing.sampleTimes[1] = (0.5);

    /* task offsets */
    ExperimentModelPIDFeedFowardDigital_M->Timing.offsetTimes[0] = (0.0);
    ExperimentModelPIDFeedFowardDigital_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(ExperimentModelPIDFeedFowardDigital_M,
             &ExperimentModelPIDFeedFowardDigital_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits =
      ExperimentModelPIDFeedFowardDigital_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    ExperimentModelPIDFeedFowardDigital_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(ExperimentModelPIDFeedFowardDigital_M, 10.0);
  ExperimentModelPIDFeedFowardDigital_M->Timing.stepSize0 = 0.001;
  ExperimentModelPIDFeedFowardDigital_M->Timing.stepSize1 = 0.5;

  /* External mode info */
  ExperimentModelPIDFeedFowardDigital_M->Sizes.checksums[0] = (2528944790U);
  ExperimentModelPIDFeedFowardDigital_M->Sizes.checksums[1] = (1213152487U);
  ExperimentModelPIDFeedFowardDigital_M->Sizes.checksums[2] = (3849772027U);
  ExperimentModelPIDFeedFowardDigital_M->Sizes.checksums[3] = (2255559190U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[2];
    ExperimentModelPIDFeedFowardDigital_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr
      (ExperimentModelPIDFeedFowardDigital_M->extModeInfo,
       &ExperimentModelPIDFeedFowardDigital_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(ExperimentModelPIDFeedFowardDigital_M->extModeInfo,
                        ExperimentModelPIDFeedFowardDigital_M->Sizes.checksums);
    rteiSetTPtr(ExperimentModelPIDFeedFowardDigital_M->extModeInfo, rtmGetTPtr
                (ExperimentModelPIDFeedFowardDigital_M));
  }

  ExperimentModelPIDFeedFowardDigital_M->solverInfoPtr =
    (&ExperimentModelPIDFeedFowardDigital_M->solverInfo);
  ExperimentModelPIDFeedFowardDigital_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&ExperimentModelPIDFeedFowardDigital_M->solverInfo, 0.001);
  rtsiSetSolverMode(&ExperimentModelPIDFeedFowardDigital_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  ExperimentModelPIDFeedFowardDigital_M->blockIO = ((void *)
    &ExperimentModelPIDFeedFowardDigital_B);
  (void) memset(((void *) &ExperimentModelPIDFeedFowardDigital_B), 0,
                sizeof(B_ExperimentModelPIDFeedFowardDigital_T));

  /* parameters */
  ExperimentModelPIDFeedFowardDigital_M->defaultParam = ((real_T *)
    &ExperimentModelPIDFeedFowardDigital_P);

  /* states (dwork) */
  ExperimentModelPIDFeedFowardDigital_M->dwork = ((void *)
    &ExperimentModelPIDFeedFowardDigital_DW);
  (void) memset((void *)&ExperimentModelPIDFeedFowardDigital_DW, 0,
                sizeof(DW_ExperimentModelPIDFeedFowardDigital_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    ExperimentModelPIDFeedFowardDigital_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 23;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  ExperimentModelPIDFeedFowardDigital_M->Sizes.numContStates = (0);/* Number of continuous states */
  ExperimentModelPIDFeedFowardDigital_M->Sizes.numY = (0);/* Number of model outputs */
  ExperimentModelPIDFeedFowardDigital_M->Sizes.numU = (0);/* Number of model inputs */
  ExperimentModelPIDFeedFowardDigital_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  ExperimentModelPIDFeedFowardDigital_M->Sizes.numSampTimes = (2);/* Number of sample times */
  ExperimentModelPIDFeedFowardDigital_M->Sizes.numBlocks = (45);/* Number of blocks */
  ExperimentModelPIDFeedFowardDigital_M->Sizes.numBlockIO = (11);/* Number of block outputs */
  ExperimentModelPIDFeedFowardDigital_M->Sizes.numBlockPrms = (59);/* Sum of parameter "widths" */
  return ExperimentModelPIDFeedFowardDigital_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
