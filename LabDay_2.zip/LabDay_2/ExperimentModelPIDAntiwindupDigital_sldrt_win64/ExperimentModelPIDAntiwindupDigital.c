/*
 * ExperimentModelPIDAntiwindupDigital.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "ExperimentModelPIDAntiwindupDigital".
 *
 * Model version              : 1.14
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Sun Apr 25 17:31:25 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ExperimentModelPIDAntiwindupDigital.h"
#include "ExperimentModelPIDAntiwindupDigital_private.h"
#include "ExperimentModelPIDAntiwindupDigital_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  2.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.001, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6221", 4294967295U, 5, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_ExperimentModelPIDAntiwindupDigital_T ExperimentModelPIDAntiwindupDigital_B;

/* Block states (default storage) */
DW_ExperimentModelPIDAntiwindupDigital_T ExperimentModelPIDAntiwindupDigital_DW;

/* Real-time model */
static RT_MODEL_ExperimentModelPIDAntiwindupDigital_T
  ExperimentModelPIDAntiwindupDigital_M_;
RT_MODEL_ExperimentModelPIDAntiwindupDigital_T *const
  ExperimentModelPIDAntiwindupDigital_M =
  &ExperimentModelPIDAntiwindupDigital_M_;

/* Model output function */
void ExperimentModelPIDAntiwindupDigital_output(void)
{
  /* local block i/o variables */
  real_T rtb_AnalogInput[2];
  real_T rtb_Sum;
  real_T rtb_Saturation;
  real_T rtb_Proportionalgain;

  /* S-Function (sldrtai): '<Root>/Analog Input' */
  /* S-Function Block: <Root>/Analog Input */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE)
      ExperimentModelPIDAntiwindupDigital_P.AnalogInput_RangeMode;
    parm.rangeidx = ExperimentModelPIDAntiwindupDigital_P.AnalogInput_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 2,
                   ExperimentModelPIDAntiwindupDigital_P.AnalogInput_Channels,
                   &rtb_AnalogInput[0], &parm);
  }

  /* S-Function (sldrtei): '<Root>/Encoder Input' */
  /* S-Function Block: <Root>/Encoder Input */
  {
    ENCODERINPARM parm;
    parm.quad = (QUADMODE) 2;
    parm.index = (INDEXPULSE) 0;
    parm.infilter =
      ExperimentModelPIDAntiwindupDigital_P.EncoderInput_InputFilter;
    RTBIO_DriverIO(0, ENCODERINPUT, IOREAD, 1,
                   &ExperimentModelPIDAntiwindupDigital_P.EncoderInput_Channels,
                   &rtb_Sum, &parm);
  }

  /* Saturate: '<S1>/Saturation' incorporates:
   *  Sum: '<Root>/Add'
   */
  rtb_Saturation = rtb_AnalogInput[0] - rtb_AnalogInput[1];

  /* Gain: '<Root>/1//Rs' */
  ExperimentModelPIDAntiwindupDigital_B.armaturecurrent = 1.0 /
    ExperimentModelPIDAntiwindupDigital_P.sens.curr.Rs * rtb_Saturation;

  /* Step: '<Root>/Position reference [deg]' */
  if (ExperimentModelPIDAntiwindupDigital_M->Timing.t[0] <
      ExperimentModelPIDAntiwindupDigital_P.Positionreferencedeg_Time) {
    /* Step: '<Root>/Position reference [deg]' */
    ExperimentModelPIDAntiwindupDigital_B.w_ref =
      ExperimentModelPIDAntiwindupDigital_P.Positionreferencedeg_Y0;
  } else {
    /* Step: '<Root>/Position reference [deg]' */
    ExperimentModelPIDAntiwindupDigital_B.w_ref =
      ExperimentModelPIDAntiwindupDigital_P.finalValue;
  }

  /* End of Step: '<Root>/Position reference [deg]' */

  /* Saturate: '<S1>/Saturation' incorporates:
   *  ZeroOrderHold: '<Root>/Zero-Order Hold'
   */
  rtb_Saturation = ExperimentModelPIDAntiwindupDigital_B.w_ref;

  /* Gain: '<Root>/pulse2deg' */
  ExperimentModelPIDAntiwindupDigital_B.thl_meas =
    ExperimentModelPIDAntiwindupDigital_P.sens.enc.pulse2deg * rtb_Sum;

  /* Saturate: '<S1>/Saturation' incorporates:
   *  Gain: '<S1>/deg2rad'
   *  Sum: '<Root>/Sum1'
   */
  rtb_Saturation = (rtb_Saturation -
                    ExperimentModelPIDAntiwindupDigital_B.thl_meas) *
    ExperimentModelPIDAntiwindupDigital_P.deg2rad;

  /* Gain: '<S1>/Proportional gain' */
  rtb_Proportionalgain = ExperimentModelPIDAntiwindupDigital_P.Kp *
    rtb_Saturation;

  /* DiscreteTransferFcn: '<S1>/Discrete Transfer Fcn' incorporates:
   *  Gain: '<S1>/Derivative gain'
   */
  ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn_tmp =
    (ExperimentModelPIDAntiwindupDigital_P.Kd * rtb_Saturation -
     ExperimentModelPIDAntiwindupDigital_P.DiscreteTransferFcn_DenCoef[1] *
     ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn_states) /
    ExperimentModelPIDAntiwindupDigital_P.DiscreteTransferFcn_DenCoef[0];

  /* Sum: '<S1>/Sum' incorporates:
   *  DiscreteTransferFcn: '<S1>/Discrete Transfer Fcn'
   */
  rtb_Sum = ExperimentModelPIDAntiwindupDigital_P.DiscreteTransferFcn_NumCoef[0]
    * ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn_tmp +
    ExperimentModelPIDAntiwindupDigital_P.DiscreteTransferFcn_NumCoef[1] *
    ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn_states;

  /* DiscreteTransferFcn: '<S1>/Discrete Transfer Fcn1' incorporates:
   *  Gain: '<S1>/Antiwindup gain'
   *  Gain: '<S1>/Integral gain'
   *  Sum: '<S1>/Sum2'
   *  UnitDelay: '<S1>/Unit Delay'
   */
  ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn1_tmp =
    ((ExperimentModelPIDAntiwindupDigital_P.Ki * rtb_Saturation -
      ExperimentModelPIDAntiwindupDigital_P.Kw *
      ExperimentModelPIDAntiwindupDigital_DW.UnitDelay_DSTATE) -
     ExperimentModelPIDAntiwindupDigital_P.DiscreteTransferFcn1_DenCoef[1] *
     ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn1_states) /
    ExperimentModelPIDAntiwindupDigital_P.DiscreteTransferFcn1_DenCoef[0];

  /* Saturate: '<S1>/Saturation' incorporates:
   *  DiscreteTransferFcn: '<S1>/Discrete Transfer Fcn1'
   */
  rtb_Saturation =
    ExperimentModelPIDAntiwindupDigital_P.DiscreteTransferFcn1_NumCoef[0] *
    ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn1_tmp +
    ExperimentModelPIDAntiwindupDigital_P.DiscreteTransferFcn1_NumCoef[1] *
    ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn1_states;

  /* Sum: '<S1>/Sum' */
  rtb_Sum = (rtb_Proportionalgain + rtb_Sum) + rtb_Saturation;

  /* Saturate: '<S1>/Saturation' */
  if (rtb_Sum > ExperimentModelPIDAntiwindupDigital_P.Saturation_UpperSat) {
    /* Saturate: '<S1>/Saturation' */
    rtb_Saturation = ExperimentModelPIDAntiwindupDigital_P.Saturation_UpperSat;
  } else if (rtb_Sum < ExperimentModelPIDAntiwindupDigital_P.Saturation_LowerSat)
  {
    /* Saturate: '<S1>/Saturation' */
    rtb_Saturation = ExperimentModelPIDAntiwindupDigital_P.Saturation_LowerSat;
  } else {
    /* Saturate: '<S1>/Saturation' */
    rtb_Saturation = rtb_Sum;
  }

  /* End of Saturate: '<S1>/Saturation' */

  /* S-Function (sldrtao): '<Root>/Analog Output' */
  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE)
        ExperimentModelPIDAntiwindupDigital_P.AnalogOutput_RangeMode;
      parm.rangeidx =
        ExperimentModelPIDAntiwindupDigital_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &ExperimentModelPIDAntiwindupDigital_P.AnalogOutput_Channels,
                     ((real_T*) (&rtb_Saturation)), &parm);
    }
  }

  /* Sum: '<S1>/Sum1' */
  ExperimentModelPIDAntiwindupDigital_B.Sum1 = rtb_Sum - rtb_Saturation;
}

/* Model update function */
void ExperimentModelPIDAntiwindupDigital_update(void)
{
  /* Update for DiscreteTransferFcn: '<S1>/Discrete Transfer Fcn' */
  ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn_states =
    ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn_tmp;

  /* Update for UnitDelay: '<S1>/Unit Delay' */
  ExperimentModelPIDAntiwindupDigital_DW.UnitDelay_DSTATE =
    ExperimentModelPIDAntiwindupDigital_B.Sum1;

  /* Update for DiscreteTransferFcn: '<S1>/Discrete Transfer Fcn1' */
  ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn1_states =
    ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn1_tmp;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++ExperimentModelPIDAntiwindupDigital_M->Timing.clockTick0)) {
    ++ExperimentModelPIDAntiwindupDigital_M->Timing.clockTickH0;
  }

  ExperimentModelPIDAntiwindupDigital_M->Timing.t[0] =
    ExperimentModelPIDAntiwindupDigital_M->Timing.clockTick0 *
    ExperimentModelPIDAntiwindupDigital_M->Timing.stepSize0 +
    ExperimentModelPIDAntiwindupDigital_M->Timing.clockTickH0 *
    ExperimentModelPIDAntiwindupDigital_M->Timing.stepSize0 * 4294967296.0;

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++ExperimentModelPIDAntiwindupDigital_M->Timing.clockTick1)) {
      ++ExperimentModelPIDAntiwindupDigital_M->Timing.clockTickH1;
    }

    ExperimentModelPIDAntiwindupDigital_M->Timing.t[1] =
      ExperimentModelPIDAntiwindupDigital_M->Timing.clockTick1 *
      ExperimentModelPIDAntiwindupDigital_M->Timing.stepSize1 +
      ExperimentModelPIDAntiwindupDigital_M->Timing.clockTickH1 *
      ExperimentModelPIDAntiwindupDigital_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Model initialize function */
void ExperimentModelPIDAntiwindupDigital_initialize(void)
{
  /* Start for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE)
        ExperimentModelPIDAntiwindupDigital_P.AnalogOutput_RangeMode;
      parm.rangeidx =
        ExperimentModelPIDAntiwindupDigital_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &ExperimentModelPIDAntiwindupDigital_P.AnalogOutput_Channels,
                     &ExperimentModelPIDAntiwindupDigital_P.AnalogOutput_InitialValue,
                     &parm);
    }
  }

  /* InitializeConditions for S-Function (sldrtei): '<Root>/Encoder Input' */

  /* S-Function Block: <Root>/Encoder Input */
  {
    ENCODERINPARM parm;
    parm.quad = (QUADMODE) 2;
    parm.index = (INDEXPULSE) 0;
    parm.infilter =
      ExperimentModelPIDAntiwindupDigital_P.EncoderInput_InputFilter;
    RTBIO_DriverIO(0, ENCODERINPUT, IORESET, 1,
                   &ExperimentModelPIDAntiwindupDigital_P.EncoderInput_Channels,
                   NULL, &parm);
  }

  /* InitializeConditions for DiscreteTransferFcn: '<S1>/Discrete Transfer Fcn' */
  ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn_states =
    ExperimentModelPIDAntiwindupDigital_P.DiscreteTransferFcn_InitialStates;

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay' */
  ExperimentModelPIDAntiwindupDigital_DW.UnitDelay_DSTATE =
    ExperimentModelPIDAntiwindupDigital_P.UnitDelay_InitialCondition;

  /* InitializeConditions for DiscreteTransferFcn: '<S1>/Discrete Transfer Fcn1' */
  ExperimentModelPIDAntiwindupDigital_DW.DiscreteTransferFcn1_states =
    ExperimentModelPIDAntiwindupDigital_P.DiscreteTransferFcn1_InitialStates;
}

/* Model terminate function */
void ExperimentModelPIDAntiwindupDigital_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE)
        ExperimentModelPIDAntiwindupDigital_P.AnalogOutput_RangeMode;
      parm.rangeidx =
        ExperimentModelPIDAntiwindupDigital_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &ExperimentModelPIDAntiwindupDigital_P.AnalogOutput_Channels,
                     &ExperimentModelPIDAntiwindupDigital_P.AnalogOutput_FinalValue,
                     &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  ExperimentModelPIDAntiwindupDigital_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  ExperimentModelPIDAntiwindupDigital_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  ExperimentModelPIDAntiwindupDigital_initialize();
}

void MdlTerminate(void)
{
  ExperimentModelPIDAntiwindupDigital_terminate();
}

/* Registration function */
RT_MODEL_ExperimentModelPIDAntiwindupDigital_T
  *ExperimentModelPIDAntiwindupDigital(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  ExperimentModelPIDAntiwindupDigital_P.EncoderInput_InputFilter = rtInf;

  /* initialize real-time model */
  (void) memset((void *)ExperimentModelPIDAntiwindupDigital_M, 0,
                sizeof(RT_MODEL_ExperimentModelPIDAntiwindupDigital_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&ExperimentModelPIDAntiwindupDigital_M->solverInfo,
                          &ExperimentModelPIDAntiwindupDigital_M->Timing.simTimeStep);
    rtsiSetTPtr(&ExperimentModelPIDAntiwindupDigital_M->solverInfo, &rtmGetTPtr
                (ExperimentModelPIDAntiwindupDigital_M));
    rtsiSetStepSizePtr(&ExperimentModelPIDAntiwindupDigital_M->solverInfo,
                       &ExperimentModelPIDAntiwindupDigital_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&ExperimentModelPIDAntiwindupDigital_M->solverInfo,
                          (&rtmGetErrorStatus
      (ExperimentModelPIDAntiwindupDigital_M)));
    rtsiSetRTModelPtr(&ExperimentModelPIDAntiwindupDigital_M->solverInfo,
                      ExperimentModelPIDAntiwindupDigital_M);
  }

  rtsiSetSimTimeStep(&ExperimentModelPIDAntiwindupDigital_M->solverInfo,
                     MAJOR_TIME_STEP);
  rtsiSetSolverName(&ExperimentModelPIDAntiwindupDigital_M->solverInfo,
                    "FixedStepDiscrete");

  /* Initialize timing info */
  {
    int_T *mdlTsMap =
      ExperimentModelPIDAntiwindupDigital_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    ExperimentModelPIDAntiwindupDigital_M->Timing.sampleTimeTaskIDPtr =
      (&mdlTsMap[0]);
    ExperimentModelPIDAntiwindupDigital_M->Timing.sampleTimes =
      (&ExperimentModelPIDAntiwindupDigital_M->Timing.sampleTimesArray[0]);
    ExperimentModelPIDAntiwindupDigital_M->Timing.offsetTimes =
      (&ExperimentModelPIDAntiwindupDigital_M->Timing.offsetTimesArray[0]);

    /* task periods */
    ExperimentModelPIDAntiwindupDigital_M->Timing.sampleTimes[0] = (0.0);
    ExperimentModelPIDAntiwindupDigital_M->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    ExperimentModelPIDAntiwindupDigital_M->Timing.offsetTimes[0] = (0.0);
    ExperimentModelPIDAntiwindupDigital_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(ExperimentModelPIDAntiwindupDigital_M,
             &ExperimentModelPIDAntiwindupDigital_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits =
      ExperimentModelPIDAntiwindupDigital_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    ExperimentModelPIDAntiwindupDigital_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(ExperimentModelPIDAntiwindupDigital_M, 10.0);
  ExperimentModelPIDAntiwindupDigital_M->Timing.stepSize0 = 0.001;
  ExperimentModelPIDAntiwindupDigital_M->Timing.stepSize1 = 0.001;

  /* External mode info */
  ExperimentModelPIDAntiwindupDigital_M->Sizes.checksums[0] = (2665573473U);
  ExperimentModelPIDAntiwindupDigital_M->Sizes.checksums[1] = (1586054041U);
  ExperimentModelPIDAntiwindupDigital_M->Sizes.checksums[2] = (298300435U);
  ExperimentModelPIDAntiwindupDigital_M->Sizes.checksums[3] = (1106635903U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    ExperimentModelPIDAntiwindupDigital_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr
      (ExperimentModelPIDAntiwindupDigital_M->extModeInfo,
       &ExperimentModelPIDAntiwindupDigital_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(ExperimentModelPIDAntiwindupDigital_M->extModeInfo,
                        ExperimentModelPIDAntiwindupDigital_M->Sizes.checksums);
    rteiSetTPtr(ExperimentModelPIDAntiwindupDigital_M->extModeInfo, rtmGetTPtr
                (ExperimentModelPIDAntiwindupDigital_M));
  }

  ExperimentModelPIDAntiwindupDigital_M->solverInfoPtr =
    (&ExperimentModelPIDAntiwindupDigital_M->solverInfo);
  ExperimentModelPIDAntiwindupDigital_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&ExperimentModelPIDAntiwindupDigital_M->solverInfo, 0.001);
  rtsiSetSolverMode(&ExperimentModelPIDAntiwindupDigital_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  ExperimentModelPIDAntiwindupDigital_M->blockIO = ((void *)
    &ExperimentModelPIDAntiwindupDigital_B);
  (void) memset(((void *) &ExperimentModelPIDAntiwindupDigital_B), 0,
                sizeof(B_ExperimentModelPIDAntiwindupDigital_T));

  /* parameters */
  ExperimentModelPIDAntiwindupDigital_M->defaultParam = ((real_T *)
    &ExperimentModelPIDAntiwindupDigital_P);

  /* states (dwork) */
  ExperimentModelPIDAntiwindupDigital_M->dwork = ((void *)
    &ExperimentModelPIDAntiwindupDigital_DW);
  (void) memset((void *)&ExperimentModelPIDAntiwindupDigital_DW, 0,
                sizeof(DW_ExperimentModelPIDAntiwindupDigital_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    ExperimentModelPIDAntiwindupDigital_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 19;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  ExperimentModelPIDAntiwindupDigital_M->Sizes.numContStates = (0);/* Number of continuous states */
  ExperimentModelPIDAntiwindupDigital_M->Sizes.numY = (0);/* Number of model outputs */
  ExperimentModelPIDAntiwindupDigital_M->Sizes.numU = (0);/* Number of model inputs */
  ExperimentModelPIDAntiwindupDigital_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  ExperimentModelPIDAntiwindupDigital_M->Sizes.numSampTimes = (2);/* Number of sample times */
  ExperimentModelPIDAntiwindupDigital_M->Sizes.numBlocks = (23);/* Number of blocks */
  ExperimentModelPIDAntiwindupDigital_M->Sizes.numBlockIO = (6);/* Number of block outputs */
  ExperimentModelPIDAntiwindupDigital_M->Sizes.numBlockPrms = (39);/* Sum of parameter "widths" */
  return ExperimentModelPIDAntiwindupDigital_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
