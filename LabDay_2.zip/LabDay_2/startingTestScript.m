%%DESIGN BY EMULATION - PID - NOMINAL PARAM.
loadParNominal;
PIDDigital;
finalValue = 50;
T1 = 0.001;
T2 = 0.01;
T3 = 0.05;
tmpTs = [T1 T2 T3];
%PID
% k = 1 -> BE
% k = 2 -> FE
% k = 3 -> tustin
% k = 4 -> zoh

% j = 1 -> T1
% j = 2 -> T2
% j = 3 -> T3

PIDScript;

Tw = ts5 / 5;
Kw = 1/Tw;
finalValue = 360;

%AntiWindup

PIDAntiWindupScript;

loadParEst;

Tw = ts5 / 5;
Kw = 1/Tw;
%FeedFoward

PIDFeedFowardScript

%%DESIGN BY EMULATION - STATE SPACE - EST PARAM.

StateSpaceControllerNominalDigital;
finalValue = 50;
%SSNominal
SSNominalScript;

%SSRobust
StateSpaceControllerRobustDigital;

SSRobustScript;

%%DIRECT DESIGN - STATE SPACE - EST PARAM.

%SSNominal

SSNominalScripDirectDigital;

%SSRobust

SSRobustScripDirectDigital;