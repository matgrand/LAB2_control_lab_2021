/*
 * ExperimentSSNominalModelDirectDigital_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "ExperimentSSNominalModelDirectDigital".
 *
 * Model version              : 1.15
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Sun Apr 25 17:58:34 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ExperimentSSNominalModelDirectDigital.h"
#include "ExperimentSSNominalModelDirectDigital_private.h"

/* Block parameters (default storage) */
P_ExperimentSSNominalModelDirectDigital_T
  ExperimentSSNominalModelDirectDigital_P = {
  /* Variable: sens
   * Referenced by:
   *   '<Root>/1//Rs'
   *   '<Root>/pulse2deg'
   */
  {
    {
      0.5
    },

    {
      2000.0,
      0.18,
      0.0031415926535897933,
      5.5555555555555554,
      318.3098861837907
    },

    {
      {
        10000.0,
        5.0,
        345.0,
        6.0213859193804371
      },
      0.014492753623188406,
      0.83037361613162786,
      69.0,
      1.2042771838760873
    }
  },

  /* Variable: Gamma0
   * Referenced by: '<S1>/Discrete State-Space'
   */
  { 0.15581575860481783, -7.0411629535263032 },

  /* Variable: H0
   * Referenced by: '<S1>/Discrete State-Space'
   */
  { 0.0, 1.0 },

  /* Variable: K
   * Referenced by: '<S1>/K'
   */
  { 66.113224348820154, 0.58024701958783453 },

  /* Variable: Nu
   * Referenced by: '<S1>/Nu'
   */
  0.0,

  /* Variable: Nx
   * Referenced by: '<S1>/Nx'
   */
  { 1.0, 0.0 },

  /* Variable: Phi0
   * Referenced by: '<S1>/Discrete State-Space'
   */
  0.9,

  /* Variable: deg2rad
   * Referenced by:
   *   '<S1>/deg2rad'
   *   '<S1>/deg2rad.'
   */
  0.017453292519943295,

  /* Variable: finalValue
   * Referenced by: '<Root>/Position reference [deg]'
   */
  50.0,

  /* Mask Parameter: AnalogOutput_FinalValue
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: AnalogOutput_InitialValue
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: EncoderInput_InputFilter
   * Referenced by: '<Root>/Encoder Input'
   */
  0.0,

  /* Mask Parameter: AnalogInput_MaxMissedTicks
   * Referenced by: '<Root>/Analog Input'
   */
  10.0,

  /* Mask Parameter: EncoderInput_MaxMissedTicks
   * Referenced by: '<Root>/Encoder Input'
   */
  10.0,

  /* Mask Parameter: AnalogOutput_MaxMissedTicks
   * Referenced by: '<Root>/Analog Output'
   */
  10.0,

  /* Mask Parameter: AnalogInput_YieldWhenWaiting
   * Referenced by: '<Root>/Analog Input'
   */
  0.0,

  /* Mask Parameter: EncoderInput_YieldWhenWaiting
   * Referenced by: '<Root>/Encoder Input'
   */
  0.0,

  /* Mask Parameter: AnalogOutput_YieldWhenWaiting
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: AnalogInput_Channels
   * Referenced by: '<Root>/Analog Input'
   */
  { 0, 1 },

  /* Mask Parameter: EncoderInput_Channels
   * Referenced by: '<Root>/Encoder Input'
   */
  0,

  /* Mask Parameter: AnalogOutput_Channels
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Mask Parameter: AnalogInput_RangeMode
   * Referenced by: '<Root>/Analog Input'
   */
  0,

  /* Mask Parameter: AnalogOutput_RangeMode
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Mask Parameter: AnalogInput_VoltRange
   * Referenced by: '<Root>/Analog Input'
   */
  0,

  /* Mask Parameter: AnalogOutput_VoltRange
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Expression: 1
   * Referenced by: '<Root>/Position reference [deg]'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Position reference [deg]'
   */
  0.0,

  /* Expression: zeros(size(H0,1),size(Gamma0,2))
   * Referenced by: '<S1>/Discrete State-Space'
   */
  { 0.0, 0.0, 0.0, 0.0 },

  /* Expression: 0
   * Referenced by: '<S1>/Discrete State-Space'
   */
  0.0,

  /* Expression: J0(:,2)
   * Referenced by: '<S1>/J0'
   */
  { 1.0, 70.411629535263032 },

  /* Expression: 10
   * Referenced by: '<S1>/Saturation'
   */
  10.0,

  /* Expression: -10
   * Referenced by: '<S1>/Saturation'
   */
  -10.0
};
