/*
 * ExperimentSSNominalModelDigital.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "ExperimentSSNominalModelDigital".
 *
 * Model version              : 1.16
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Sun Apr 25 17:56:31 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ExperimentSSNominalModelDigital.h"
#include "ExperimentSSNominalModelDigital_private.h"
#include "ExperimentSSNominalModelDigital_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  2.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.001, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6221", 4294967295U, 5, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_ExperimentSSNominalModelDigital_T ExperimentSSNominalModelDigital_B;

/* Block states (default storage) */
DW_ExperimentSSNominalModelDigital_T ExperimentSSNominalModelDigital_DW;

/* Real-time model */
static RT_MODEL_ExperimentSSNominalModelDigital_T
  ExperimentSSNominalModelDigital_M_;
RT_MODEL_ExperimentSSNominalModelDigital_T *const
  ExperimentSSNominalModelDigital_M = &ExperimentSSNominalModelDigital_M_;

/* Model output function */
void ExperimentSSNominalModelDigital_output(void)
{
  /* local block i/o variables */
  real_T rtb_Sum[2];
  real_T rtb_Saturation;
  real_T rtb_Nu;
  real_T rtb_deg2rad;

  /* S-Function (sldrtai): '<Root>/Analog Input' */
  /* S-Function Block: <Root>/Analog Input */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE)
      ExperimentSSNominalModelDigital_P.AnalogInput_RangeMode;
    parm.rangeidx = ExperimentSSNominalModelDigital_P.AnalogInput_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 2,
                   ExperimentSSNominalModelDigital_P.AnalogInput_Channels,
                   &rtb_Sum[0], &parm);
  }

  /* S-Function (sldrtei): '<Root>/Encoder Input' */
  /* S-Function Block: <Root>/Encoder Input */
  {
    ENCODERINPARM parm;
    parm.quad = (QUADMODE) 2;
    parm.index = (INDEXPULSE) 0;
    parm.infilter = ExperimentSSNominalModelDigital_P.EncoderInput_InputFilter;
    RTBIO_DriverIO(0, ENCODERINPUT, IOREAD, 1,
                   &ExperimentSSNominalModelDigital_P.EncoderInput_Channels,
                   &rtb_Saturation, &parm);
  }

  /* Gain: '<Root>/1//Rs' incorporates:
   *  Sum: '<Root>/Add'
   */
  ExperimentSSNominalModelDigital_B.armaturecurrent = 1.0 /
    ExperimentSSNominalModelDigital_P.sens.curr.Rs * (rtb_Sum[0] - rtb_Sum[1]);

  /* Step: '<Root>/Position reference [deg]' */
  if (ExperimentSSNominalModelDigital_M->Timing.t[0] <
      ExperimentSSNominalModelDigital_P.Positionreferencedeg_Time) {
    /* Step: '<Root>/Position reference [deg]' */
    ExperimentSSNominalModelDigital_B.w_ref =
      ExperimentSSNominalModelDigital_P.Positionreferencedeg_Y0;
  } else {
    /* Step: '<Root>/Position reference [deg]' */
    ExperimentSSNominalModelDigital_B.w_ref =
      ExperimentSSNominalModelDigital_P.finalValue;
  }

  /* End of Step: '<Root>/Position reference [deg]' */

  /* Gain: '<S1>/deg2rad.' incorporates:
   *  ZeroOrderHold: '<Root>/Zero-Order Hold'
   */
  rtb_deg2rad = ExperimentSSNominalModelDigital_P.deg2rad *
    ExperimentSSNominalModelDigital_B.w_ref;

  /* Gain: '<S1>/Nu' */
  rtb_Nu = ExperimentSSNominalModelDigital_P.Nu * rtb_deg2rad;

  /* Sum: '<S1>/Sum' incorporates:
   *  Gain: '<S1>/Nx'
   */
  rtb_Sum[0] = ExperimentSSNominalModelDigital_P.Nx[0] * rtb_deg2rad;
  rtb_Sum[1] = ExperimentSSNominalModelDigital_P.Nx[1] * rtb_deg2rad;

  /* Gain: '<Root>/pulse2deg' */
  ExperimentSSNominalModelDigital_B.thl_meas =
    ExperimentSSNominalModelDigital_P.sens.enc.pulse2deg * rtb_Saturation;

  /* Gain: '<S1>/deg2rad' */
  rtb_deg2rad = ExperimentSSNominalModelDigital_P.deg2rad *
    ExperimentSSNominalModelDigital_B.thl_meas;

  /* Sum: '<S1>/Sum' incorporates:
   *  DiscreteStateSpace: '<S1>/Discrete State-Space'
   *  Gain: '<S1>/J0'
   *  Sum: '<S1>/Sum2'
   */
  rtb_Sum[0] -= ExperimentSSNominalModelDigital_P.H0[0] *
    ExperimentSSNominalModelDigital_DW.DiscreteStateSpace_DSTATE +
    ExperimentSSNominalModelDigital_P.J0_Gain[0] * rtb_deg2rad;
  rtb_Sum[1] -= ExperimentSSNominalModelDigital_P.H0[1] *
    ExperimentSSNominalModelDigital_DW.DiscreteStateSpace_DSTATE +
    ExperimentSSNominalModelDigital_P.J0_Gain[1] * rtb_deg2rad;

  /* Saturate: '<S1>/Saturation' incorporates:
   *  Gain: '<S1>/K'
   *  Sum: '<S1>/Sum1'
   */
  rtb_Saturation = ExperimentSSNominalModelDigital_P.K[0] * rtb_Sum[0] +
    ExperimentSSNominalModelDigital_P.K[1] * rtb_Sum[1];
  rtb_Saturation += rtb_Nu;

  /* Saturate: '<S1>/Saturation' */
  if (rtb_Saturation > ExperimentSSNominalModelDigital_P.Saturation_UpperSat) {
    /* Saturate: '<S1>/Saturation' */
    rtb_Saturation = ExperimentSSNominalModelDigital_P.Saturation_UpperSat;
  } else {
    if (rtb_Saturation < ExperimentSSNominalModelDigital_P.Saturation_LowerSat)
    {
      /* Saturate: '<S1>/Saturation' */
      rtb_Saturation = ExperimentSSNominalModelDigital_P.Saturation_LowerSat;
    }
  }

  /* End of Saturate: '<S1>/Saturation' */

  /* S-Function (sldrtao): '<Root>/Analog Output' */
  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE)
        ExperimentSSNominalModelDigital_P.AnalogOutput_RangeMode;
      parm.rangeidx = ExperimentSSNominalModelDigital_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &ExperimentSSNominalModelDigital_P.AnalogOutput_Channels,
                     ((real_T*) (&rtb_Saturation)), &parm);
    }
  }

  /* SignalConversion generated from: '<S1>/Discrete State-Space' */
  ExperimentSSNominalModelDigital_B.TmpSignalConversionAtDiscreteStateSpaceInport1
    [0] = rtb_Saturation;
  ExperimentSSNominalModelDigital_B.TmpSignalConversionAtDiscreteStateSpaceInport1
    [1] = rtb_deg2rad;
}

/* Model update function */
void ExperimentSSNominalModelDigital_update(void)
{
  /* Update for DiscreteStateSpace: '<S1>/Discrete State-Space' */
  ExperimentSSNominalModelDigital_DW.DiscreteStateSpace_DSTATE =
    (ExperimentSSNominalModelDigital_P.Phi0 *
     ExperimentSSNominalModelDigital_DW.DiscreteStateSpace_DSTATE +
     ExperimentSSNominalModelDigital_P.Gamma0[0] *
     ExperimentSSNominalModelDigital_B.TmpSignalConversionAtDiscreteStateSpaceInport1
     [0]) + ExperimentSSNominalModelDigital_P.Gamma0[1] *
    ExperimentSSNominalModelDigital_B.TmpSignalConversionAtDiscreteStateSpaceInport1
    [1];

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++ExperimentSSNominalModelDigital_M->Timing.clockTick0)) {
    ++ExperimentSSNominalModelDigital_M->Timing.clockTickH0;
  }

  ExperimentSSNominalModelDigital_M->Timing.t[0] =
    ExperimentSSNominalModelDigital_M->Timing.clockTick0 *
    ExperimentSSNominalModelDigital_M->Timing.stepSize0 +
    ExperimentSSNominalModelDigital_M->Timing.clockTickH0 *
    ExperimentSSNominalModelDigital_M->Timing.stepSize0 * 4294967296.0;

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++ExperimentSSNominalModelDigital_M->Timing.clockTick1)) {
      ++ExperimentSSNominalModelDigital_M->Timing.clockTickH1;
    }

    ExperimentSSNominalModelDigital_M->Timing.t[1] =
      ExperimentSSNominalModelDigital_M->Timing.clockTick1 *
      ExperimentSSNominalModelDigital_M->Timing.stepSize1 +
      ExperimentSSNominalModelDigital_M->Timing.clockTickH1 *
      ExperimentSSNominalModelDigital_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Model initialize function */
void ExperimentSSNominalModelDigital_initialize(void)
{
  /* Start for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE)
        ExperimentSSNominalModelDigital_P.AnalogOutput_RangeMode;
      parm.rangeidx = ExperimentSSNominalModelDigital_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &ExperimentSSNominalModelDigital_P.AnalogOutput_Channels,
                     &ExperimentSSNominalModelDigital_P.AnalogOutput_InitialValue,
                     &parm);
    }
  }

  /* InitializeConditions for S-Function (sldrtei): '<Root>/Encoder Input' */

  /* S-Function Block: <Root>/Encoder Input */
  {
    ENCODERINPARM parm;
    parm.quad = (QUADMODE) 2;
    parm.index = (INDEXPULSE) 0;
    parm.infilter = ExperimentSSNominalModelDigital_P.EncoderInput_InputFilter;
    RTBIO_DriverIO(0, ENCODERINPUT, IORESET, 1,
                   &ExperimentSSNominalModelDigital_P.EncoderInput_Channels,
                   NULL, &parm);
  }

  /* InitializeConditions for DiscreteStateSpace: '<S1>/Discrete State-Space' */
  ExperimentSSNominalModelDigital_DW.DiscreteStateSpace_DSTATE =
    ExperimentSSNominalModelDigital_P.DiscreteStateSpace_InitialCondition;
}

/* Model terminate function */
void ExperimentSSNominalModelDigital_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE)
        ExperimentSSNominalModelDigital_P.AnalogOutput_RangeMode;
      parm.rangeidx = ExperimentSSNominalModelDigital_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &ExperimentSSNominalModelDigital_P.AnalogOutput_Channels,
                     &ExperimentSSNominalModelDigital_P.AnalogOutput_FinalValue,
                     &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  ExperimentSSNominalModelDigital_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  ExperimentSSNominalModelDigital_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  ExperimentSSNominalModelDigital_initialize();
}

void MdlTerminate(void)
{
  ExperimentSSNominalModelDigital_terminate();
}

/* Registration function */
RT_MODEL_ExperimentSSNominalModelDigital_T *ExperimentSSNominalModelDigital(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  ExperimentSSNominalModelDigital_P.EncoderInput_InputFilter = rtInf;

  /* initialize real-time model */
  (void) memset((void *)ExperimentSSNominalModelDigital_M, 0,
                sizeof(RT_MODEL_ExperimentSSNominalModelDigital_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&ExperimentSSNominalModelDigital_M->solverInfo,
                          &ExperimentSSNominalModelDigital_M->Timing.simTimeStep);
    rtsiSetTPtr(&ExperimentSSNominalModelDigital_M->solverInfo, &rtmGetTPtr
                (ExperimentSSNominalModelDigital_M));
    rtsiSetStepSizePtr(&ExperimentSSNominalModelDigital_M->solverInfo,
                       &ExperimentSSNominalModelDigital_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&ExperimentSSNominalModelDigital_M->solverInfo,
                          (&rtmGetErrorStatus(ExperimentSSNominalModelDigital_M)));
    rtsiSetRTModelPtr(&ExperimentSSNominalModelDigital_M->solverInfo,
                      ExperimentSSNominalModelDigital_M);
  }

  rtsiSetSimTimeStep(&ExperimentSSNominalModelDigital_M->solverInfo,
                     MAJOR_TIME_STEP);
  rtsiSetSolverName(&ExperimentSSNominalModelDigital_M->solverInfo,
                    "FixedStepDiscrete");

  /* Initialize timing info */
  {
    int_T *mdlTsMap =
      ExperimentSSNominalModelDigital_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    ExperimentSSNominalModelDigital_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    ExperimentSSNominalModelDigital_M->Timing.sampleTimes =
      (&ExperimentSSNominalModelDigital_M->Timing.sampleTimesArray[0]);
    ExperimentSSNominalModelDigital_M->Timing.offsetTimes =
      (&ExperimentSSNominalModelDigital_M->Timing.offsetTimesArray[0]);

    /* task periods */
    ExperimentSSNominalModelDigital_M->Timing.sampleTimes[0] = (0.0);
    ExperimentSSNominalModelDigital_M->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    ExperimentSSNominalModelDigital_M->Timing.offsetTimes[0] = (0.0);
    ExperimentSSNominalModelDigital_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(ExperimentSSNominalModelDigital_M,
             &ExperimentSSNominalModelDigital_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits =
      ExperimentSSNominalModelDigital_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    ExperimentSSNominalModelDigital_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(ExperimentSSNominalModelDigital_M, 10.0);
  ExperimentSSNominalModelDigital_M->Timing.stepSize0 = 0.001;
  ExperimentSSNominalModelDigital_M->Timing.stepSize1 = 0.001;

  /* External mode info */
  ExperimentSSNominalModelDigital_M->Sizes.checksums[0] = (565975867U);
  ExperimentSSNominalModelDigital_M->Sizes.checksums[1] = (1655844954U);
  ExperimentSSNominalModelDigital_M->Sizes.checksums[2] = (122814388U);
  ExperimentSSNominalModelDigital_M->Sizes.checksums[3] = (2977235134U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    ExperimentSSNominalModelDigital_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(ExperimentSSNominalModelDigital_M->extModeInfo,
      &ExperimentSSNominalModelDigital_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(ExperimentSSNominalModelDigital_M->extModeInfo,
                        ExperimentSSNominalModelDigital_M->Sizes.checksums);
    rteiSetTPtr(ExperimentSSNominalModelDigital_M->extModeInfo, rtmGetTPtr
                (ExperimentSSNominalModelDigital_M));
  }

  ExperimentSSNominalModelDigital_M->solverInfoPtr =
    (&ExperimentSSNominalModelDigital_M->solverInfo);
  ExperimentSSNominalModelDigital_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&ExperimentSSNominalModelDigital_M->solverInfo, 0.001);
  rtsiSetSolverMode(&ExperimentSSNominalModelDigital_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  ExperimentSSNominalModelDigital_M->blockIO = ((void *)
    &ExperimentSSNominalModelDigital_B);
  (void) memset(((void *) &ExperimentSSNominalModelDigital_B), 0,
                sizeof(B_ExperimentSSNominalModelDigital_T));

  /* parameters */
  ExperimentSSNominalModelDigital_M->defaultParam = ((real_T *)
    &ExperimentSSNominalModelDigital_P);

  /* states (dwork) */
  ExperimentSSNominalModelDigital_M->dwork = ((void *)
    &ExperimentSSNominalModelDigital_DW);
  (void) memset((void *)&ExperimentSSNominalModelDigital_DW, 0,
                sizeof(DW_ExperimentSSNominalModelDigital_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    ExperimentSSNominalModelDigital_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 19;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  ExperimentSSNominalModelDigital_M->Sizes.numContStates = (0);/* Number of continuous states */
  ExperimentSSNominalModelDigital_M->Sizes.numY = (0);/* Number of model outputs */
  ExperimentSSNominalModelDigital_M->Sizes.numU = (0);/* Number of model inputs */
  ExperimentSSNominalModelDigital_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  ExperimentSSNominalModelDigital_M->Sizes.numSampTimes = (2);/* Number of sample times */
  ExperimentSSNominalModelDigital_M->Sizes.numBlocks = (22);/* Number of blocks */
  ExperimentSSNominalModelDigital_M->Sizes.numBlockIO = (4);/* Number of block outputs */
  ExperimentSSNominalModelDigital_M->Sizes.numBlockPrms = (41);/* Sum of parameter "widths" */
  return ExperimentSSNominalModelDigital_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
